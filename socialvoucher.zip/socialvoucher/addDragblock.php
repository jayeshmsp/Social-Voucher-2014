<?php

include_once 'app/Mage.php';
 
Mage::app();

try{
	
	// usage /scripts/addToCart.php?product_id=838&qty=1
	$id = '';
	
	if($_REQUEST['id'] == 'customer')
	{
		      
		        $user1 = Mage::getSingleton('customer/session')->getCustomer();
				$user_id1 = $user1->getEntityId();
				
				$read= Mage::getSingleton('core/resource')->getConnection('core_read');
				
				$value=$read->query("SELECT count(*) as cnt from sv_merchantdashboard where merchantdashboard_block = 'customer' AND merchantdashboard_userid ='".$user_id1."' ");
				$row = $value->fetch();
			
				if($row['cnt'] == 0)
				{	
				
				$connection = Mage::getSingleton('core/resource')->getConnection('core_write');
				// insert
				$sql = "INSERT INTO `sv_merchantdashboard` (`merchantdashboard_userid`,`merchantdashboard_block`,`merchantdashboard_active`,`merchantdashboard_createdat`) VALUES ('".$_REQUEST['user_id']."','customer','1',now())";
				$connection->query($sql);
				}
	}
	if($_REQUEST['id'] == 'product')
	{         
	            $user1 = Mage::getSingleton('customer/session')->getCustomer();
				$user_id1 = $user1->getEntityId();
		        
				$read= Mage::getSingleton('core/resource')->getConnection('core_read');
				
				$value=$read->query("SELECT count(*) as cnt from sv_merchantdashboard where merchantdashboard_block = 'product' AND merchantdashboard_userid ='".$user_id1."' ");
				$row = $value->fetch();
				
				if($row['cnt'] == 0)
				{	
				
				$connection = Mage::getSingleton('core/resource')->getConnection('core_write');
				// insert
				$sql = "INSERT INTO `sv_merchantdashboard` (`merchantdashboard_userid`,`merchantdashboard_block`,`merchantdashboard_active`,`merchantdashboard_createdat`) VALUES ('".$_REQUEST['user_id']."','product','1',now())";
				$connection->query($sql);
				}
	}
	if($_REQUEST['id'] == 'topcustomer')
	{  
	            $user1 = Mage::getSingleton('customer/session')->getCustomer();
				$user_id1 = $user1->getEntityId();
		        
				$read= Mage::getSingleton('core/resource')->getConnection('core_read');
				
				$value=$read->query("SELECT count(*) as cnt from sv_merchantdashboard where merchantdashboard_block = 'topcustomer' AND merchantdashboard_userid ='".$user_id1."' ");
				$row = $value->fetch();
				 if($row['cnt'] == 0)
				{	
				
				$connection = Mage::getSingleton('core/resource')->getConnection('core_write');
				// insert
				$sql = "INSERT INTO `sv_merchantdashboard` (`merchantdashboard_userid`,`merchantdashboard_block`,`merchantdashboard_active`,`merchantdashboard_createdat`) VALUES ('".$_REQUEST['user_id']."','topcustomer','1',now())";
				$connection->query($sql);
				}
				  
	}
	if($_REQUEST['id'] == 'topcampaigns')
	{  
	            $user1 = Mage::getSingleton('customer/session')->getCustomer();
				$user_id1 = $user1->getEntityId();
		        
				$read= Mage::getSingleton('core/resource')->getConnection('core_read');
				
				$value=$read->query("SELECT count(*) as cnt from sv_merchantdashboard where merchantdashboard_block = 'topcampaigns' AND merchantdashboard_userid ='".$user_id1."' ");
				$row = $value->fetch();
				 if($row['cnt'] == 0)
				{	
				
				$connection = Mage::getSingleton('core/resource')->getConnection('core_write');
				// insert
				$sql = "INSERT INTO `sv_merchantdashboard` (`merchantdashboard_userid`,`merchantdashboard_block`,`merchantdashboard_active`,`merchantdashboard_createdat`) VALUES ('".$_REQUEST['user_id']."','topcampaigns','1',now())";
				$connection->query($sql);
				}
	}
	
	if($_REQUEST['id'] == 'customergrowth')
	{  
	            $user1 = Mage::getSingleton('customer/session')->getCustomer();
				$user_id1 = $user1->getEntityId();
		        
				$read= Mage::getSingleton('core/resource')->getConnection('core_read');
				
				$value=$read->query("SELECT count(*) as cnt from sv_merchantdashboard where merchantdashboard_block = 'customergrowth' AND merchantdashboard_userid ='".$user_id1."' ");
				$row = $value->fetch();
				 if($row['cnt'] == 0)
				{	
				
				$connection = Mage::getSingleton('core/resource')->getConnection('core_write');
				// insert
				$sql = "INSERT INTO `sv_merchantdashboard` (`merchantdashboard_userid`,`merchantdashboard_block`,`merchantdashboard_active`,`merchantdashboard_createdat`) VALUES ('".$_REQUEST['user_id']."','customergrowth','1',now())";
				$connection->query($sql);
				}
	}
	 
	  if($_REQUEST['id'] == 'fbstaticstic')
	{  
	            $user1 = Mage::getSingleton('customer/session')->getCustomer();
				$user_id1 = $user1->getEntityId();
		        
				$read= Mage::getSingleton('core/resource')->getConnection('core_read');
				
				$value=$read->query("SELECT count(*) as cnt from sv_merchantdashboard where merchantdashboard_block = 'fbstaticstic' AND merchantdashboard_userid ='".$user_id1."' ");
				$row = $value->fetch();
				 if($row['cnt'] == 0)
				{	
				
				$connection = Mage::getSingleton('core/resource')->getConnection('core_write');
				// insert
				$sql = "INSERT INTO `sv_merchantdashboard` (`merchantdashboard_userid`,`merchantdashboard_block`,`merchantdashboard_active`,`merchantdashboard_createdat`) VALUES ('".$_REQUEST['user_id']."','fbstaticstic','1',now())";
				$connection->query($sql);
				}
	}
	
	
	echo $result;
 
} catch (Exception $e) {
	$result = "{'result':'error'";
	$result .= ", 'message': '".$e->getMessage()."'}";
	echo $result;
}