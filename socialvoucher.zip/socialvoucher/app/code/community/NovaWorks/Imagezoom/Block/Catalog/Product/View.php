<?php
class NovaWorks_Imagezoom_Block_Catalog_Product_View extends Mage_Catalog_Block_Product_View
{
}
