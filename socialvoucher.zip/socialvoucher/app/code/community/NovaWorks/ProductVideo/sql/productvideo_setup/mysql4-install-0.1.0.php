<?php
$installer = $this;
$installer->startSetup();

$installer->installEntities();

$installer->endSetup();