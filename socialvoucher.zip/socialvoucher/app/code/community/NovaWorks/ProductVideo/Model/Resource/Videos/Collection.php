<?php
class NovaWorks_ProductVideo_Model_Resource_Videos_Collection extends Mage_Core_Model_Mysql4_Collection_Abstract
{
    public function _construct()
    {
        parent::_construct();
        $this->_init('productvideo/videos');
    }
}










