<?php
class NovaWorks_FacebookConnect_Mysql4_Setup extends Mage_Eav_Model_Entity_Setup
{
}
