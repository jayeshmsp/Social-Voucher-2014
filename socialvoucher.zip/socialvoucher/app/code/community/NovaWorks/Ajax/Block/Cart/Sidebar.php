<?php
class NovaWorks_Ajax_Block_Cart_Sidebar extends Mage_Checkout_Block_Cart_Sidebar{
}